from flask import Flask, render_template, request
from leaf1 import pred_tomato_diseases


from price import price_app

app = Flask(__name__)

# Register the blueprint from the price.py file
app.register_blueprint(price_app)

@app.route('/price')
def price():
    # call a function in price_app to get the list of PDF files
    pdf_files = price_app.index()

    # render the template with the list of PDF files
    #return render_template('price.html', pdf_files=pdf_files)



@app.route('/')
def index():
    return render_template('main_index.html')

@app.route('/team')
def team():
    return render_template('index.html')

@app.route('/fla_k')
def fla_k():
    return render_template('silkworm_Flacheria_ka.html')

@app.route('/fla_e')
def fla_e():
    return render_template('silkworm_Flacheria.html')

@app.route('/gra_k')
def gra_k():
    return render_template('silkworm_Grasseria_ka.html')

@app.route('/gra_e')
def gra_e():
    return render_template('silkworm_Grasseria.html')

@app.route('/mus_k')
def mus_k():
    return render_template('silkworm_muscardin_ka.html')

@app.route('/mus_e')
def mus_e():
    return render_template('silkworm_muscardin.html')

@app.route('/pab_k')
def pab_k():
    return render_template('silkworm_pabrin_ka.html')

@app.route('/pab_e')
def pab_e():
    return render_template('silkworm_pabrin.html')

@app.route('/home')
def home():
    return render_template('main.html')

@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/week1_k')
def week1_k():
    return render_template('week1_k.html')
@app.route('/week1')
def week1():
    return render_template('week1.html')
@app.route('/week2_k')
def week2_k():
    return render_template('week2_k.html')
@app.route('/week2')
def week2():
    return render_template('week2.html')
@app.route('/week3_k')
def week3_k():
    return render_template('week3_k.html')
@app.route('/week3')
def week3():
    return render_template('week3.html')
@app.route('/week4_k')
def week4_k():
    return render_template('week4_k.html')
@app.route('/week4')
def week4():
    return render_template('week4.html')
@app.route('/week5_k')
def week5_k():
    return render_template('week5_k.html')
@app.route('/week5')
def week5():
    return render_template('week5.html')


pages = {
    'week1': 'week1.html',
    'week2': 'week2.html',
    'week3': 'week3.html',
     'week4': 'week4.html',
      'week5': 'week5.html'
}

@app.route('/stage', methods=['GET', 'POST'])
def stage():
    if request.method == 'POST':
        # Get the user input from the request form
        input = request.form['input']

        # Check if the user input matches a page in the dictionary
        if input in pages:
            # If it does, render the corresponding page
            page = pages[input]
            return render_template(page)
        else:
            # If it doesn't, return an error message
            return "Error: Page not found."
    else:
        # If the request method is GET, return the form for user input
        return render_template('index_stage.html')


@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        file = request.files['image']
        file_path = 'static/uploads/' + file.filename
        file.save(file_path)
        pred, output_page = pred_tomato_diseases(tomato_plant=file_path)
        return render_template(output_page, pred_output=pred, user_image=file_path)
    return render_template('index.html')



if __name__ == '__main__':
    app.run(debug=True)
